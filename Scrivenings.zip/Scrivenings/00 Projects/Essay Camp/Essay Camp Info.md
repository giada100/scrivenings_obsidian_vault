---
created: 2023-10-27T12:59
updated: 2023-10-27T13:04
Source: https://www.awritersnotebook.org/p/essay-camp-a-november-write-along
---
# Essay Camp: A November Write-Along

**What:** Essay Camp: A November Write-Along

**When:** Wednesday November 1st – Sunday November 5th, 2023, plus the option to continue.

**Where**: Online

**Who:** Award-winning writer and author [Summer Brennan](https://www.summer-brennan.com/) teaches essay writing and the creative process, with thousands of writers participating.

**How:** [Sign up for free emails from A Writer’s Notebook](https://summerbrennan.substack.com/subscribe) and follow along at home.

**Why:** Reconnect with your writing practice and plant the seeds for future success.

**Cost:** None.

**Details:**

Join thousands of other writers for a five-day essay writing workshop in the write-along style. After the five days are up, those who wish to continue a daily nonfiction writing practice for the rest of November as an alternative to [National Novel Writing Month (NaNoWriMo)](https://en.wikipedia.org/wiki/National_Novel_Writing_Month) can do so with encouragement and support using the Substack Chat feature.

The ongoing process of writing is one of perpetual drift and return. We are pulled away from our writing practice and then we come back, over and over. Life, the noise of the world, and the constant clamor of our own personal responsibilities can make writing difficult. **This habit of return is one of the most important skills that any writer can cultivate, whether we do it daily or only once every few years.**

The primary goal of Essay Camp is simply to get you writing again. If you’re already writing, it is to connect with your established practice in a deeper way.

Participants receive daily emails with suggested writing and reading assignments that can be tailored to fit any schedule. There are no specific time or word-count requirements. Each writer is encouraged to make a creative plan for the workshop that fits their own individual needs. At the end of the five days we’ll look back at what we’ve written and spend some time crafting **at least one finished essay or other piece of writing** from the accumulated material. It doesn’t have to be perfect, it just has to be _done_.

If you want to participate and [you’re already signed up to get the free or paid version of this newsletter](https://summerbrennan.substack.com/subscribe), you’re all set! If you’re not signed up and wish to do so, you can sign up below. Remember, if you only wish to recieve Essay Camp emails and _not_ the full newsletter, be sure to check and uncheck the appropriate boxes on your subscription management page.

See you in November!