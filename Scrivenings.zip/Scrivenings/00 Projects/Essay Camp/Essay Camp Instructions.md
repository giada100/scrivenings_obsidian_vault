---
created: 2023-10-27T13:02
updated: 2023-10-27T13:03
Source: https://www.awritersnotebook.org/p/essay-camp-starts-wednesday
---
# Essay Camp Starts Wednesday 

Here’s what you’ll need:

1. **Yourself**
    
    In order to attend Essay Camp you will need to show up. All versions of yourself—the talented, the untalented, the sure, the unsure, the prepared, the unprepared—are all invited and encouraged to attend. Essay Camp is virtual and happens wherever you are—a hut in the forest, your office after hours, your car in the parking lot of a Dunkin’ Donuts, the locked bathroom of your one-bedroom apartment while an angry toddler bangs on the door before being dragged away screaming by your spouse. Essay Camp must happen wherever you are _mentally_, as well. Over the next few days, _**see if you can locate yourself**_. Get out a bullhorn and announce to yourself as loudly as you can that you’ll be doing some creative writing next week, Wednesday through Sunday, every day for five days. Bang on some pots and pans to get your attention if you have to. Let the part of you that writes things know that it is time to wake up now and report for duty.
    
2. **Time**
    
    In order to attend Essay Camp, you will need to set aside some time every day. Ideally this should include time spent actively writing, but also some _additional_ time spent thinking, daydreaming, reading, walking, or all of the above. The instruction emails will give suggested assignments for reading and writing, and propose some strategies for revision towards the end. How _much_ time you spend on any of these activities is up to you. Do try to budget them in. You may want to take some time now to come up with a tentative schedule. Do you write best first thing in the morning? Or right before you go to bed? Do you plan to set your alarm for 6 a.m. instead of 7, or will you reserve an hour to yourself after everyone else is asleep? Can you spare two hours between work and dinner to go for a walk, and then do some writing afterwards? How about fifteen minutes to take a walk around the neighborhood, and then another fifteen minutes to scribble something down when you get back? Can you arrive thirty minutes early to work and write in your car? I like to take walks in the evenings, and then write first thing in the morning when I get up. It doesn’t have to be the same time every day, or even the same amount of time, but do try to get a sense of when or how you plan to fit some writing into your schedule. **Remember, this is not a word count-based writing challenge.** Even if you just write five sentences each day—more on this option later—the goal is to strengthen and enrich your writing practice as a whole.
    
3. **Tools**
    
    In order to write, you will need something to write with. Whether it’s a special notebook, a typewriter, a laptop, your phone, or a public computer at the library, it doesn’t really matter as long as it serves _you_. Some writers like to use special materials to honor the process, while others find that low-cost or low-stakes supplies and programs can keep the pressure off. If you don’t know what you prefer, try a few things and see how they strike you. Go to the supermarket or a stationery store and pick up some new pens and notebooks that inspire you. Play around with writing or productivity apps. **Bonus:** If you feel so inclined, try something new. Studies have shown that writing by hand on paper can help increase your thinking and memory, while typing is best for transcribing your thoughts as they form. Ask yourself—do you want to mull over what you’re writing? Or do you prefer to get your thoughts down quickly as they appear in your mind, as if out of nowhere? Rumination, or stream of consciousness? What happens to your process when you try different methods? Just something to think about!
    
4. **Space**
    
    In order to attend Essay Camp, you must physically exist in the world. This is difficult at times, but unavoidable. Where do you plan to write? I’ve been doing a lot of my writing this year in a special room at the library, but I also like to write at a sidewalk café, with my laptop on the couch, or in bed. You may prefer writing at a desk or at the kitchen table, in private, or at a busy restaurant. Even if you plan to do most of your writing in public—at work, the library, in a parked car, whatever—**try to set aside a little corner for yourself at home that is dedicated solely to your writing**. Commandeer the coffee table. Cordon off a little corner of the dining room, bedroom, or kitchen if you have to, but take a whole surface or desk if you can. If you can manage it this weekend, see if you can designate such a space. If you already have one, clean it off. Then see if there is anything you can do to spruce it up a bit. If you have a desk, clear away the dust and clutter. If you’ll be writing at the kitchen table, spring for a bouquet of flowers, a new candle, or a pretty bowl of fruit. As I wrote in my post about [how to create a DIY writing residency](https://summerbrennan.substack.com/p/the-diy-writing-residency?s=w), sometimes it helps to create a sense of abundance and a “container” for your writing if you pamper yourself and your space a little bit first.
    

Now that you know what you _will_ need, here is what you _won’t_ need:

1. **Ideas**
    
    There is no need to come to Essay Camp already knowing what you plan to write about. In fact, it’s probably better if you don’t. If you do have some general ideas, that’s completely fine and good, but **do not feel like you have to have anything mapped out beforehand**. While we _are_ doing this Essay Camp session during [NaNoWriMo](https://en.wikipedia.org/wiki/National_Novel_Writing_Month) this year, with its talk of “pantsers” and “planners,” this isn’t that.
    
2. **Confidence**
    
    There is no need to be confident or even to believe in yourself. This is an exercise, not a performance. You never have to show anyone what you write during Essay Camp. The only wrong way to be is absent.
    
3. **Talent**
    
    I said this higher up in the post, but it’s worth repeating: you do not have to be good at writing to attend Essay Camp. As James Baldwin once said: **“Talent is insignificant. I know a lot of talented ruins. Beyond talent lie all the usual words: discipline, love, luck, but, most of all, endurance.”**
    

And that’s it!

If you can gather together a little time, a little space, something to write with, and some version of yourself—no matter how bedraggled—you should be all set!

Instruction emails will go out each morning at 6am, Central European Time. If you’re already a free subscriber to [A Writer’s Notebook](https://summerbrennan.substack.com/subscribe), then you’re all set. If not, you can subscribe below:

To post and discuss on Notes, Instagram, and other social media, please use the hashtag #EssayCamp to find one another, or look for the special Essay Camp feed on BlueSky. There are now **over 14,000** of you signed up to receive these emails, so I hope this can translate into a sense of community for those who want it.

**After the five days are up, those who wish to do so can continue the daily writing practice for the full month of November. While there won’t be daily emails going out like during the first five days, I will be continuing, and will be posting and checking in with ongoing Essay Campers via Substack Chat.**

If you have any questions, please put them in the comments below. I will do my best to answer them as soon as I can!

Essay Camp is free, but your subscriptions keep the lights on. If you’re in a position to become a paying subscriber, please do.

See you soon!

xo

Summer
